//+------------------------------------------------------------------+
//|                         CRT_XAUUSD_EA.mq5                       |
//|          Candle Range Theory Expert Advisor for XAUUSD           |
//|          Timeframe: 1H Setup + 3M Entry | NY Session 8am-5pm     |
//|          Strategy: CRT 3-Candle Pattern with CISD/CHoCH Entry    |
//+------------------------------------------------------------------+
#property copyright   "CRT Trading Bot"
#property version     "2.00"
#property strict

#include <Trade\Trade.mqh>
#include <Trade\PositionInfo.mqh>
#include <Trade\OrderInfo.mqh>

//=== INPUT PARAMETERS ===================================================
input group "=== SESSION SETTINGS ==="
input int    InpSessionStartHour   = 8;    // NY Session Start Hour (Server Time offset applied)
input int    InpSessionEndHour     = 17;   // NY Session End Hour
input int    InpServerOffsetHours  = 0;    // Server UTC offset vs NY (adjust for your broker)

input group "=== CRT DETECTION - CANDLE 1 (Range Candle) ==="
input double InpMinBodyRatio       = 0.6;  // Min body/total range ratio for Candle1 (0.6 = 60% body)
input double InpMinCandlePoints    = 100;  // Min Candle1 height in points (XAUUSD: 100 = $1.00)
input int    InpLookback           = 5;    // Bars to look back for Candle1 candidates

input group "=== CRT DETECTION - CANDLE 2 (Manipulation/Sweep Candle) ==="
input double InpMaxBodyRatio       = 0.35; // Max body/total range ratio for Candle2 (indecision)
input double InpMinWickRatio       = 0.45; // Min wick ratio to qualify as indecision candle

input group "=== SENTIMENT FILTER ==="
input bool   InpUseSentimentFilter = true;  // Enable daily bias/sentiment filter
input int    InpEMAPeriod          = 50;    // EMA period for trend bias (applied on 1H chart)
input int    InpADXPeriod          = 14;    // ADX period for trend strength
input double InpADXThreshold       = 20.0;  // Min ADX for trend confirmation

input group "=== RISK MANAGEMENT ==="
input double InpRiskPercent        = 1.0;  // Risk per trade (% of account balance)
input double InpRRRatio            = 2.0;  // Risk:Reward ratio (e.g. 2.0 = 1:2 RR)
input int    InpMaxDailyTrades     = 3;    // Max trades per day

input group "=== ENTRY SETTINGS ==="
input int    InpEntry3MTimeoutBars = 20;   // Max 3M bars to wait for retest after CISD
input double InpRetestTolerancePts = 15;   // Retest zone tolerance in points

input group "=== GENERAL ==="
input long   InpMagicNumber        = 202401; // EA Magic Number
input bool   InpEnableAlerts       = true;   // Enable push/sound alerts
input bool   InpEnableLogging      = true;   // Enable detailed logging

//=== GLOBAL VARIABLES ===================================================
CTrade         trade;
CPositionInfo  posInfo;

// CRT Pattern State Machine
enum CRTState {
   STATE_IDLE,            // Waiting for Candle1
   STATE_C1_IDENTIFIED,   // Candle1 confirmed, waiting for Candle2 sweep
   STATE_C2_SWEPT,        // Candle2 swept & closed inside C1 range
   STATE_AWAITING_CISD,   // Waiting for price to cross C2 close (CISD/CHoCH)
   STATE_CISD_CONFIRMED,  // CISD confirmed, dropped to 3M for retest entry
   STATE_IN_TRADE         // Trade is live
};

CRTState       g_state          = STATE_IDLE;
bool           g_bullishSetup   = false;   // true = bullish CRT, false = bearish
double         g_c1High         = 0;
double         g_c1Low          = 0;
double         g_c1Open         = 0;
double         g_c1Close        = 0;
double         g_c2Close        = 0;       // CISD level
double         g_entryLevel     = 0;       // Retest / entry price
double         g_takeProfit     = 0;
double         g_stopLoss       = 0;
datetime       g_c1Time         = 0;
datetime       g_c2Time         = 0;
datetime       g_cisdTime       = 0;
int            g_dailyTradeCount = 0;
datetime       g_lastTradeDate   = 0;
int            g_3mTimeoutCount  = 0;

// Indicator handles
int h_ema1H   = INVALID_HANDLE;
int h_adx1H   = INVALID_HANDLE;

// Timer for 3M monitoring
datetime       g_lastBarTime3M  = 0;

//=== INITIALIZATION =====================================================
int OnInit() {
   trade.SetExpertMagicNumber(InpMagicNumber);
   trade.SetDeviationInPoints(20);
   trade.SetTypeFilling(ORDER_FILLING_FOK);

   // Create indicator handles on 1H
   h_ema1H = iMA(_Symbol, PERIOD_H1, InpEMAPeriod, 0, MODE_EMA, PRICE_CLOSE);
   h_adx1H = iADX(_Symbol, PERIOD_H1, InpADXPeriod);

   if(h_ema1H == INVALID_HANDLE || h_adx1H == INVALID_HANDLE) {
      Print("ERROR: Failed to create indicator handles");
      return(INIT_FAILED);
   }

   Log("CRT EA Initialized. Symbol=" + _Symbol + " Magic=" + IntegerToString(InpMagicNumber));
   return(INIT_SUCCEEDED);
}

//=== DEINITIALIZATION ===================================================
void OnDeinit(const int reason) {
   if(h_ema1H != INVALID_HANDLE) IndicatorRelease(h_ema1H);
   if(h_adx1H != INVALID_HANDLE) IndicatorRelease(h_adx1H);
}

//=== MAIN TICK ==========================================================
void OnTick() {
   // ---- Daily trade counter reset ----
   datetime today = StringToTime(TimeToString(TimeCurrent(), TIME_DATE));
   if(today != g_lastTradeDate) {
      g_dailyTradeCount = 0;
      g_lastTradeDate   = today;
      g_state           = STATE_IDLE;  // Reset at start of new day
      Log("New trading day. State reset.");
   }

   // ---- Max daily trades guard ----
   if(g_dailyTradeCount >= InpMaxDailyTrades) return;

   // ---- Session check ----
   if(!InSession()) return;

   // ---- Route to correct state handler ----
   switch(g_state) {
      case STATE_IDLE:            Handle_Idle();           break;
      case STATE_C1_IDENTIFIED:   Handle_C1Identified();   break;
      case STATE_C2_SWEPT:        Handle_C2Swept();        break;
      case STATE_AWAITING_CISD:   Handle_AwaitingCISD();   break;
      case STATE_CISD_CONFIRMED:  Handle_CISDConfirmed();  break;
      case STATE_IN_TRADE:        Handle_InTrade();        break;
   }
}

//=== STATE: IDLE — Scan for Candle1 ====================================
void Handle_Idle() {
   // Only scan on new 1H bar
   static datetime lastBar1H = 0;
   datetime currentBar = iTime(_Symbol, PERIOD_H1, 0);
   if(currentBar == lastBar1H) return;
   lastBar1H = currentBar;

   // Get market sentiment / daily bias
   bool bullishBias, bearishBias;
   GetDailyBias(bullishBias, bearishBias);

   // Scan recent closed 1H candles for valid Candle1
   for(int i = 1; i <= InpLookback; i++) {
      double hi    = iHigh(_Symbol,  PERIOD_H1, i);
      double lo    = iLow(_Symbol,   PERIOD_H1, i);
      double op    = iOpen(_Symbol,  PERIOD_H1, i);
      double cl    = iClose(_Symbol, PERIOD_H1, i);
      datetime t   = iTime(_Symbol,  PERIOD_H1, i);

      if(IsStrongCandle1(op, hi, lo, cl)) {
         // Candle1 bias must align with daily bias
         bool c1Bullish = (cl > op);  // bullish body
         if(InpUseSentimentFilter) {
            if(bullishBias && !c1Bullish) continue;   // looking for LOW sweep → need prior bullish or neutral C1
            if(bearishBias && c1Bullish) continue;
         }

         g_c1High      = hi;
         g_c1Low       = lo;
         g_c1Open      = op;
         g_c1Close     = cl;
         g_c1Time      = t;
         g_bullishSetup = bullishBias && !bearishBias;  // default: follow bias

         g_state = STATE_C1_IDENTIFIED;
         Log(StringFormat("C1 Identified at bar %d | H=%.3f L=%.3f | Bullish setup=%s",
             i, g_c1High, g_c1Low, g_bullishSetup ? "YES" : "NO"));
         if(InpEnableAlerts) Alert("CRT: Candle1 Identified on " + _Symbol);
         break;
      }
   }
}

//=== STATE: C1 Identified — Wait for Candle2 sweep + close inside =====
void Handle_C1Identified() {
   static datetime lastBar1H = 0;
   datetime currentBar = iTime(_Symbol, PERIOD_H1, 0);
   if(currentBar == lastBar1H) return;
   lastBar1H = currentBar;

   // Candle2 = the bar that just closed (index 1)
   double c2Hi  = iHigh(_Symbol,  PERIOD_H1, 1);
   double c2Lo  = iLow(_Symbol,   PERIOD_H1, 1);
   double c2Op  = iOpen(_Symbol,  PERIOD_H1, 1);
   double c2Cl  = iClose(_Symbol, PERIOD_H1, 1);
   datetime c2T = iTime(_Symbol,  PERIOD_H1, 1);

   // Only look at the immediate next candle after C1
   if(c2T <= g_c1Time) return;

   // Rule 1: Candle2 must sweep ONE side only of C1 range
   bool sweptHigh = (c2Hi > g_c1High);
   bool sweptLow  = (c2Lo < g_c1Low);

   // Must sweep exactly one side
   if(sweptHigh && sweptLow) {
      Log("C2: Swept BOTH sides - invalid. Resetting.");
      g_state = STATE_IDLE;
      return;
   }
   if(!sweptHigh && !sweptLow) {
      Log("C2: No sweep detected. Waiting...");
      return;
   }

   // Rule 2: Candle2 must CLOSE INSIDE C1 range
   if(c2Cl > g_c1High || c2Cl < g_c1Low) {
      Log("C2 swept but closed OUTSIDE C1 range - invalid.");
      g_state = STATE_IDLE;
      return;
   }

   // Rule 3: Candle2 must be an indecision candle (doji, hammer, etc.)
   if(!IsIndecisionCandle(c2Op, c2Hi, c2Lo, c2Cl)) {
      Log("C2: Not an indecision candle. Resetting.");
      g_state = STATE_IDLE;
      return;
   }

   // All checks passed — record C2 and setup direction
   g_c2Close     = c2Cl;
   g_c2Time      = c2T;

   // Direction: if C1 HIGH swept → bearish setup (target = C1 LOW)
   //            if C1 LOW swept  → bullish setup (target = C1 HIGH)
   g_bullishSetup = sweptLow;

   // Validate alignment with daily bias filter
   if(InpUseSentimentFilter) {
      bool bullishBias, bearishBias;
      GetDailyBias(bullishBias, bearishBias);
      if(g_bullishSetup && bearishBias && !bullishBias) {
         Log("C2 sweep direction conflicts with daily bias. Resetting.");
         g_state = STATE_IDLE;
         return;
      }
      if(!g_bullishSetup && bullishBias && !bearishBias) {
         Log("C2 sweep direction conflicts with daily bias. Resetting.");
         g_state = STATE_IDLE;
         return;
      }
   }

   g_takeProfit = g_bullishSetup ? g_c1High : g_c1Low;
   g_state      = STATE_AWAITING_CISD;

   Log(StringFormat("C2 Confirmed! Swept=%s | C2 Close=%.3f | TP Target=%.3f | Awaiting CISD...",
       sweptLow ? "LOW" : "HIGH", g_c2Close, g_takeProfit));
   if(InpEnableAlerts) Alert("CRT: C2 Sweep Confirmed! Waiting for CISD/CHoCH cross.");
}

//=== STATE: C2 Swept — (legacy, transitions directly in C1 handler) =====
void Handle_C2Swept() {
   // Handled inline — transition to AWAITING_CISD done in Handle_C1Identified
   g_state = STATE_AWAITING_CISD;
}

//=== STATE: Awaiting CISD — Price must cross C2 close ==================
void Handle_AwaitingCISD() {
   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);

   bool cisdTriggered = false;
   if(g_bullishSetup) {
      // Bullish: price must close ABOVE C2 close on 1H
      cisdTriggered = (bid > g_c2Close + InpRetestTolerancePts * _Point);
   } else {
      // Bearish: price must close BELOW C2 close on 1H
      cisdTriggered = (ask < g_c2Close - InpRetestTolerancePts * _Point);
   }

   if(cisdTriggered) {
      g_cisdTime       = TimeCurrent();
      g_3mTimeoutCount = 0;
      g_state          = STATE_CISD_CONFIRMED;
      Log(StringFormat("CISD/CHoCH Confirmed! Price crossed C2 close %.3f | Dropping to 3M chart.", g_c2Close));
      if(InpEnableAlerts) Alert("CRT: CISD Confirmed! Monitoring 3M for retest entry.");
   }

   // Timeout: if too many 1H bars have passed, reset
   static datetime lastCheck1H = 0;
   datetime bar1H = iTime(_Symbol, PERIOD_H1, 0);
   if(bar1H != lastCheck1H) {
      lastCheck1H = bar1H;
      // If more than 4 hours have passed since C2 without CISD, reset
      if(TimeCurrent() - g_c2Time > 4 * 3600) {
         Log("CISD timeout — 4 hours elapsed since C2. Resetting.");
         g_state = STATE_IDLE;
      }
   }
}

//=== STATE: CISD Confirmed — Monitor 3M chart for retest entry =========
void Handle_CISDConfirmed() {
   // Monitor on new 3M bars
   datetime bar3M = iTime(_Symbol, PERIOD_M3, 0);
   if(bar3M == g_lastBarTime3M) return;
   g_lastBarTime3M = bar3M;
   g_3mTimeoutCount++;

   // Timeout guard
   if(g_3mTimeoutCount > InpEntry3MTimeoutBars) {
      Log("3M retest timeout. Resetting state.");
      g_state = STATE_IDLE;
      return;
   }

   double bid = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double ask = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double retestZoneHigh = g_c2Close + InpRetestTolerancePts * _Point;
   double retestZoneLow  = g_c2Close - InpRetestTolerancePts * _Point;

   // Check for retest of CISD level on 3M
   bool retestHit = false;
   if(g_bullishSetup && ask >= retestZoneLow && ask <= retestZoneHigh) retestHit = true;
   if(!g_bullishSetup && bid >= retestZoneLow && bid <= retestZoneHigh) retestHit = true;

   if(retestHit) {
      ExecuteTrade();
   }
}

//=== STATE: In Trade — Monitor open position ============================
void Handle_InTrade() {
   // Check if our position is still open
   bool posOpen = false;
   for(int i = 0; i < PositionsTotal(); i++) {
      if(posInfo.SelectByIndex(i)) {
         if(posInfo.Magic() == InpMagicNumber && posInfo.Symbol() == _Symbol) {
            posOpen = true;
            break;
         }
      }
   }
   if(!posOpen) {
      Log("Trade closed. Returning to IDLE.");
      g_state = STATE_IDLE;
   }
}

//=== TRADE EXECUTION ====================================================
void ExecuteTrade() {
   if(g_dailyTradeCount >= InpMaxDailyTrades) {
      Log("Max daily trades reached. No trade executed.");
      g_state = STATE_IDLE;
      return;
   }

   double ask   = SymbolInfoDouble(_Symbol, SYMBOL_ASK);
   double bid   = SymbolInfoDouble(_Symbol, SYMBOL_BID);
   double entry = g_bullishSetup ? ask : bid;
   double tp    = g_takeProfit;

   // Calculate SL from 1:2 RR
   double tpDistance = MathAbs(tp - entry);
   double slDistance = tpDistance / InpRRRatio;

   double sl;
   if(g_bullishSetup) {
      sl = entry - slDistance;
   } else {
      sl = entry + slDistance;
   }

   // Normalize prices
   int digits = (int)SymbolInfoInteger(_Symbol, SYMBOL_DIGITS);
   entry = NormalizeDouble(entry, digits);
   tp    = NormalizeDouble(tp,    digits);
   sl    = NormalizeDouble(sl,    digits);

   // Validate minimum SL distance
   double minStop = SymbolInfoInteger(_Symbol, SYMBOL_TRADE_STOPS_LEVEL) * _Point;
   if(slDistance < minStop) {
      Log(StringFormat("SL distance %.3f below broker minimum %.3f. Adjusting.", slDistance, minStop));
      sl = g_bullishSetup ? entry - minStop * 1.5 : entry + minStop * 1.5;
      slDistance = minStop * 1.5;
      tpDistance = slDistance * InpRRRatio;
      tp = g_bullishSetup ? entry + tpDistance : entry - tpDistance;
   }

   // Position sizing — risk 1% of balance
   double lotSize = CalculateLotSize(slDistance);
   if(lotSize <= 0) {
      Log("Invalid lot size calculated. Aborting trade.");
      g_state = STATE_IDLE;
      return;
   }

   // Execute order
   bool result = false;
   if(g_bullishSetup) {
      result = trade.Buy(lotSize, _Symbol, entry, sl, tp,
                         "CRT_Bull_" + IntegerToString(InpMagicNumber));
   } else {
      result = trade.Sell(lotSize, _Symbol, entry, sl, tp,
                          "CRT_Bear_" + IntegerToString(InpMagicNumber));
   }

   if(result) {
      g_dailyTradeCount++;
      g_state = STATE_IN_TRADE;
      Log(StringFormat("TRADE EXECUTED | %s | Entry=%.3f | SL=%.3f | TP=%.3f | Lots=%.2f | Risk=1%%",
          g_bullishSetup ? "BUY" : "SELL", entry, sl, tp, lotSize));
      if(InpEnableAlerts)
         Alert(StringFormat("CRT TRADE: %s XAUUSD | SL=%.2f TP=%.2f | Lots=%.2f",
               g_bullishSetup ? "BUY" : "SELL", sl, tp, lotSize));
   } else {
      Log("Trade execution FAILED: " + IntegerToString(trade.ResultRetcode()) +
          " " + trade.ResultRetcodeDescription());
      g_state = STATE_IDLE;
   }
}

//=== HELPERS ============================================================

// Check if within NY session window
bool InSession() {
   MqlDateTime dt;
   TimeCurrent(dt);
   int serverHour = dt.hour;
   int nyHour     = serverHour - InpServerOffsetHours;
   if(nyHour < 0)  nyHour += 24;
   if(nyHour >= 24) nyHour -= 24;

   // Avoid trading 30 min before session end
   if(nyHour < InpSessionStartHour) return false;
   if(nyHour >= InpSessionEndHour)  return false;
   return true;
}

// Strong Candle1: large body, substantial size
bool IsStrongCandle1(double op, double hi, double lo, double cl) {
   double totalRange = hi - lo;
   if(totalRange < InpMinCandlePoints * _Point) return false;
   double body = MathAbs(cl - op);
   double bodyRatio = (totalRange > 0) ? body / totalRange : 0;
   return (bodyRatio >= InpMinBodyRatio);
}

// Indecision candle: doji, hammer, shooting star, spinning top, etc.
bool IsIndecisionCandle(double op, double hi, double lo, double cl) {
   double totalRange = hi - lo;
   if(totalRange < 5 * _Point) return false;  // Too tiny

   double body     = MathAbs(cl - op);
   double bodyRatio = body / totalRange;

   // Small body relative to total range (indecision)
   if(bodyRatio <= InpMaxBodyRatio) return true;

   // Check for hammer / hanging man / shooting star (large single wick)
   double upperWick = hi - MathMax(op, cl);
   double lowerWick = MathMin(op, cl) - lo;
   double maxWick   = MathMax(upperWick, lowerWick);
   double wickRatio = maxWick / totalRange;

   return (wickRatio >= InpMinWickRatio);
}

// Get daily bias via EMA and ADX on 1H chart
void GetDailyBias(bool &bullish, bool &bearish) {
   bullish = false;
   bearish = false;

   if(!InpUseSentimentFilter) {
      bullish = true;
      bearish = true;
      return;
   }

   double ema[];
   double adx[], diPlus[], diMinus[];
   ArraySetAsSeries(ema, true);
   ArraySetAsSeries(adx, true);
   ArraySetAsSeries(diPlus, true);
   ArraySetAsSeries(diMinus, true);

   if(CopyBuffer(h_ema1H, 0, 0, 3, ema) < 3) return;
   if(CopyBuffer(h_adx1H, 0, 0, 3, adx) < 3) return;
   if(CopyBuffer(h_adx1H, 1, 0, 3, diPlus) < 3) return;
   if(CopyBuffer(h_adx1H, 2, 0, 3, diMinus) < 3) return;

   double close1H = iClose(_Symbol, PERIOD_H1, 1);
   bool   trending = (adx[1] >= InpADXThreshold);

   if(trending) {
      bullish = (close1H > ema[1] && diPlus[1] > diMinus[1]);
      bearish = (close1H < ema[1] && diMinus[1] > diPlus[1]);
   } else {
      // Ranging market — allow both directions
      bullish = true;
      bearish = true;
   }
}

// Risk-based position sizing
double CalculateLotSize(double slDistancePrice) {
   double balance     = AccountInfoDouble(ACCOUNT_BALANCE);
   double riskAmount  = balance * InpRiskPercent / 100.0;
   double tickValue   = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_VALUE);
   double tickSize    = SymbolInfoDouble(_Symbol, SYMBOL_TRADE_TICK_SIZE);

   if(tickSize <= 0 || tickValue <= 0 || slDistancePrice <= 0) return 0;

   double valuePerLot = (slDistancePrice / tickSize) * tickValue;
   if(valuePerLot <= 0) return 0;

   double lots     = riskAmount / valuePerLot;
   double minLot   = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MIN);
   double maxLot   = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_MAX);
   double stepLot  = SymbolInfoDouble(_Symbol, SYMBOL_VOLUME_STEP);

   lots = MathFloor(lots / stepLot) * stepLot;
   lots = MathMax(lots, minLot);
   lots = MathMin(lots, maxLot);

   return NormalizeDouble(lots, 2);
}

// Logging helper
void Log(string msg) {
   if(InpEnableLogging) {
      string timestamp = TimeToString(TimeCurrent(), TIME_DATE | TIME_SECONDS);
      Print("[CRT_EA] [" + timestamp + "] " + msg);
   }
}

//=== END OF EA ==========================================================
