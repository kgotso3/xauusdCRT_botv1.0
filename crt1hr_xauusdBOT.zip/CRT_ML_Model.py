"""
CRT_ML_Model.py
================
Machine Learning companion for the CRT XAUUSD Expert Advisor.

This module provides:
  1. CRTPatternClassifier  — Trains/infers on historical OHLCV data to score
                              CRT setups (probability of success).
  2. SentimentEngine       — Aggregates RSI, ATR, EMA, session bias, and
                              optional news sentiment to derive a daily bias.
  3. ModelBridge           — Exposes a named-pipe / socket interface so the
                              MT5 EA can call the model in real-time via a
                              Python EA bridge script.

Dependencies:
    pip install pandas numpy scikit-learn xgboost MetaTrader5 ta flask

Usage (standalone backtest):
    python CRT_ML_Model.py --mode backtest --symbol XAUUSD --bars 5000

Usage (live server for EA):
    python CRT_ML_Model.py --mode serve --port 5050
"""

import argparse
import json
import logging
import os
import sys
import time
import warnings
from datetime import datetime, timezone
from typing import Optional, Tuple

import numpy as np
import pandas as pd

# Optional: MetaTrader5 for live data (only on Windows with MT5 installed)
try:
    import MetaTrader5 as mt5
    MT5_AVAILABLE = True
except ImportError:
    MT5_AVAILABLE = False
    warnings.warn("MetaTrader5 package not available. Live feed disabled.")

# ML libraries
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import classification_report, roc_auc_score
from sklearn.pipeline import Pipeline
import joblib

try:
    from xgboost import XGBClassifier
    XGBOOST_AVAILABLE = True
except ImportError:
    XGBOOST_AVAILABLE = False

# Technical Analysis
try:
    import ta
    TA_AVAILABLE = True
except ImportError:
    TA_AVAILABLE = False
    warnings.warn("'ta' library not installed. Falling back to manual indicator calc.")

# Flask for serving the model
try:
    from flask import Flask, request, jsonify
    FLASK_AVAILABLE = True
except ImportError:
    FLASK_AVAILABLE = False

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler(sys.stdout)]
)
log = logging.getLogger("CRT_ML")

# ============================================================
# CONSTANTS
# ============================================================
MODEL_PATH    = "crt_model.pkl"
SCALER_PATH   = "crt_scaler.pkl"
SYMBOL        = "XAUUSD"
TF_H1         = mt5.TIMEFRAME_H1 if MT5_AVAILABLE else 16385  # mt5 code for H1
TF_M3         = mt5.TIMEFRAME_M3 if MT5_AVAILABLE else 3      # mt5 code for M3

NY_START_HOUR = 8   # in NY time (UTC-4 or UTC-5 depending on DST)
NY_END_HOUR   = 17

# ============================================================
# FEATURE ENGINEERING
# ============================================================

class FeatureEngineer:
    """
    Converts raw OHLCV bars into a feature matrix for CRT setup scoring.
    """

    @staticmethod
    def body_ratio(op: float, hi: float, lo: float, cl: float) -> float:
        rng = hi - lo
        if rng == 0:
            return 0.0
        return abs(cl - op) / rng

    @staticmethod
    def upper_wick_ratio(op: float, hi: float, lo: float, cl: float) -> float:
        rng = hi - lo
        if rng == 0:
            return 0.0
        return (hi - max(op, cl)) / rng

    @staticmethod
    def lower_wick_ratio(op: float, hi: float, lo: float, cl: float) -> float:
        rng = hi - lo
        if rng == 0:
            return 0.0
        return (min(op, cl) - lo) / rng

    @staticmethod
    def is_indecision(op: float, hi: float, lo: float, cl: float,
                      max_body_ratio: float = 0.35) -> int:
        return int(FeatureEngineer.body_ratio(op, hi, lo, cl) <= max_body_ratio)

    @staticmethod
    def is_strong_candle(op: float, hi: float, lo: float, cl: float,
                         min_body_ratio: float = 0.6,
                         min_range_pct: float = 0.001) -> int:
        rng = hi - lo
        avg_price = (hi + lo) / 2
        if avg_price == 0:
            return 0
        range_pct = rng / avg_price
        br = FeatureEngineer.body_ratio(op, hi, lo, cl)
        return int(br >= min_body_ratio and range_pct >= min_range_pct)

    @staticmethod
    def swept_side(c1_hi: float, c1_lo: float,
                   c2_hi: float, c2_lo: float) -> int:
        """Returns: 1=low swept (bullish), -1=high swept (bearish), 0=none/both"""
        swept_hi = c2_hi > c1_hi
        swept_lo = c2_lo < c1_lo
        if swept_lo and not swept_hi:
            return 1
        if swept_hi and not swept_lo:
            return -1
        return 0

    @staticmethod
    def c2_closed_inside(c1_hi: float, c1_lo: float, c2_cl: float) -> int:
        return int(c1_lo <= c2_cl <= c1_hi)

    @classmethod
    def build_features(cls, df: pd.DataFrame) -> pd.DataFrame:
        """
        Given a DataFrame with columns [open, high, low, close, volume, time],
        build a feature matrix for each potential CRT setup.

        Returns a DataFrame of features (one row per C1 candidate).
        """
        features = []
        n = len(df)

        for i in range(2, n - 1):
            # C1 = i, C2 = i+1, C3 starts at i+2
            c1 = df.iloc[i]
            c2 = df.iloc[i + 1] if i + 1 < n else None
            c3 = df.iloc[i + 2] if i + 2 < n else None
            prev = df.iloc[i - 1]

            if c2 is None or c3 is None:
                continue

            # --- C1 features ---
            c1_br     = cls.body_ratio(c1.open, c1.high, c1.low, c1.close)
            c1_strong = cls.is_strong_candle(c1.open, c1.high, c1.low, c1.close)
            c1_rng    = c1.high - c1.low
            c1_bull   = int(c1.close > c1.open)

            # --- C2 features ---
            c2_br         = cls.body_ratio(c2.open, c2.high, c2.low, c2.close)
            c2_indecision = cls.is_indecision(c2.open, c2.high, c2.low, c2.close)
            c2_upper_wick = cls.upper_wick_ratio(c2.open, c2.high, c2.low, c2.close)
            c2_lower_wick = cls.lower_wick_ratio(c2.open, c2.high, c2.low, c2.close)
            sweep         = cls.swept_side(c1.high, c1.low, c2.high, c2.low)
            c2_inside     = cls.c2_closed_inside(c1.high, c1.low, c2.close)
            sweep_depth_pct = 0.0
            if sweep == 1 and c1_rng > 0:
                sweep_depth_pct = (c1.low - c2.low) / c1_rng
            elif sweep == -1 and c1_rng > 0:
                sweep_depth_pct = (c2.high - c1.high) / c1_rng

            # --- Relationship between C1 and C2 ---
            c2_close_pct_in_c1 = 0.0
            if c1_rng > 0:
                c2_close_pct_in_c1 = (c2.close - c1.low) / c1_rng  # 0=at low, 1=at high

            # --- Trend context (prior 5 candles EMA-like) ---
            lookback = df.iloc[max(0, i-5):i]
            avg_close = lookback["close"].mean()
            trend_slope = (c1.close - lookback["close"].iloc[0]) / (lookback["close"].iloc[0] + 1e-9)

            # --- Volatility ---
            atr = lookback.apply(
                lambda r: r.high - r.low, axis=1).mean()
            c1_atr_ratio = c1_rng / (atr + 1e-9)

            # --- Volume (if available) ---
            rel_vol = 1.0
            if "volume" in df.columns and atr > 0:
                avg_vol = lookback["volume"].mean()
                rel_vol = c2.volume / (avg_vol + 1e-9)

            # --- Session ---
            hour = pd.to_datetime(c1.time).hour if hasattr(c1.time, "__class__") else 9
            in_session = int(NY_START_HOUR <= hour < NY_END_HOUR)

            feat = {
                "c1_body_ratio":        c1_br,
                "c1_strong":            c1_strong,
                "c1_range_pts":         c1_rng,
                "c1_bullish":           c1_bull,
                "c2_body_ratio":        c2_br,
                "c2_indecision":        c2_indecision,
                "c2_upper_wick":        c2_upper_wick,
                "c2_lower_wick":        c2_lower_wick,
                "sweep_direction":      sweep,
                "sweep_depth_pct":      sweep_depth_pct,
                "c2_closed_inside":     c2_inside,
                "c2_close_pct_in_c1":   c2_close_pct_in_c1,
                "trend_slope":          trend_slope,
                "c1_atr_ratio":         c1_atr_ratio,
                "rel_volume_c2":        rel_vol,
                "in_session":           in_session,
                "bar_index":            i,
            }
            features.append(feat)

        return pd.DataFrame(features)


# ============================================================
# LABEL GENERATION (for training)
# ============================================================

def generate_labels(df: pd.DataFrame, features_df: pd.DataFrame,
                    rr_ratio: float = 2.0) -> pd.Series:
    """
    Simulate CRT trade outcome from historical data.
    Label = 1 if trade was profitable at 1:RR target, else 0.
    """
    labels = []
    n = len(df)

    for _, row in features_df.iterrows():
        i = int(row["bar_index"])
        if i + 2 >= n:
            labels.append(np.nan)
            continue

        c1 = df.iloc[i]
        c2 = df.iloc[i + 1]
        sweep = row["sweep_direction"]

        if sweep == 0 or row["c2_closed_inside"] == 0:
            labels.append(0)
            continue

        entry = c2.close
        if sweep == 1:   # bullish: target = c1.high
            tp = c1.high
            sl_dist = abs(tp - entry) / rr_ratio
            sl = entry - sl_dist
        else:             # bearish: target = c1.low
            tp = c1.low
            sl_dist = abs(entry - tp) / rr_ratio
            sl = entry + sl_dist

        # Walk forward from C3 onwards
        result = 0
        for j in range(i + 2, min(i + 20, n)):
            bar = df.iloc[j]
            if sweep == 1:
                if bar.low <= sl:
                    result = 0
                    break
                if bar.high >= tp:
                    result = 1
                    break
            else:
                if bar.high >= sl:
                    result = 0
                    break
                if bar.low <= tp:
                    result = 1
                    break
        labels.append(result)

    return pd.Series(labels, name="label")


# ============================================================
# MODEL
# ============================================================

class CRTPatternClassifier:
    """
    Trains an ensemble ML model to classify CRT setups as high/low probability.
    """

    def __init__(self, model_type: str = "xgb"):
        self.model_type = model_type
        self.model = None
        self.scaler = StandardScaler()
        self.feature_cols = None
        self.threshold = 0.55  # Probability threshold for trade confirmation

    def _build_model(self):
        if self.model_type == "xgb" and XGBOOST_AVAILABLE:
            return XGBClassifier(
                n_estimators=200,
                max_depth=5,
                learning_rate=0.05,
                subsample=0.8,
                colsample_bytree=0.8,
                use_label_encoder=False,
                eval_metric="logloss",
                random_state=42
            )
        elif self.model_type == "rf":
            return RandomForestClassifier(
                n_estimators=200,
                max_depth=8,
                min_samples_leaf=5,
                random_state=42,
                n_jobs=-1
            )
        elif self.model_type == "gb":
            return GradientBoostingClassifier(
                n_estimators=200,
                max_depth=4,
                learning_rate=0.05,
                random_state=42
            )
        else:
            return LogisticRegression(max_iter=1000, random_state=42)

    def train(self, df: pd.DataFrame, rr_ratio: float = 2.0):
        log.info("Building features from %d bars...", len(df))
        features_df = FeatureEngineer.build_features(df)
        labels      = generate_labels(df, features_df, rr_ratio)

        # Combine and drop NaN
        combined = pd.concat([features_df, labels], axis=1).dropna()
        combined = combined[combined["sweep_direction"] != 0]
        combined = combined[combined["c2_closed_inside"] == 1]
        combined = combined[combined["c1_strong"] == 1]

        X = combined.drop(columns=["label", "bar_index"])
        y = combined["label"].astype(int)
        self.feature_cols = X.columns.tolist()

        log.info("Dataset: %d samples | Class balance: %.1f%% wins",
                 len(y), y.mean() * 100)

        if len(y) < 50:
            log.warning("Insufficient data for reliable training (< 50 samples).")

        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y if y.nunique() > 1 else None
        )

        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled  = self.scaler.transform(X_test)

        self.model = self._build_model()
        log.info("Training %s model...", self.model_type.upper())
        self.model.fit(X_train_scaled, y_train)

        # Evaluation
        y_pred = self.model.predict(X_test_scaled)
        y_prob = self.model.predict_proba(X_test_scaled)[:, 1]
        log.info("\n" + classification_report(y_test, y_pred, target_names=["Loss", "Win"]))
        try:
            auc = roc_auc_score(y_test, y_prob)
            log.info("ROC-AUC: %.3f", auc)
        except Exception:
            pass

        # Cross-validation
        cv_scores = cross_val_score(self.model, self.scaler.transform(X), y, cv=5, scoring="roc_auc")
        log.info("CV ROC-AUC: %.3f +/- %.3f", cv_scores.mean(), cv_scores.std())

        self.save()
        return {"auc": float(cv_scores.mean()), "n_samples": int(len(y)), "win_rate": float(y.mean())}

    def predict(self, setup: dict) -> Tuple[int, float]:
        """
        Given a dict of feature values, returns (signal: 0/1, probability: float).
        """
        if self.model is None or self.feature_cols is None:
            raise RuntimeError("Model not trained. Call train() or load() first.")

        row = {col: setup.get(col, 0.0) for col in self.feature_cols}
        X = pd.DataFrame([row])[self.feature_cols]
        X_scaled = self.scaler.transform(X)
        prob = self.model.predict_proba(X_scaled)[0][1]
        signal = int(prob >= self.threshold)
        return signal, float(prob)

    def save(self):
        joblib.dump(self.model, MODEL_PATH)
        joblib.dump((self.scaler, self.feature_cols), SCALER_PATH)
        log.info("Model saved: %s, %s", MODEL_PATH, SCALER_PATH)

    def load(self):
        if not os.path.exists(MODEL_PATH):
            raise FileNotFoundError(f"Model file not found: {MODEL_PATH}. Train first.")
        self.model = joblib.load(MODEL_PATH)
        self.scaler, self.feature_cols = joblib.load(SCALER_PATH)
        log.info("Model loaded from disk.")


# ============================================================
# SENTIMENT ENGINE
# ============================================================

class SentimentEngine:
    """
    Derives daily bias (bullish / bearish / neutral) for XAUUSD
    using multi-factor technical analysis on 1H data.
    """

    @staticmethod
    def compute_bias(df_1h: pd.DataFrame) -> dict:
        """
        df_1h: DataFrame with columns [open, high, low, close, volume]
        Returns dict with keys: bias ('bullish'|'bearish'|'neutral'), strength (0-1), factors
        """
        if len(df_1h) < 50:
            return {"bias": "neutral", "strength": 0.5, "factors": {}}

        closes = df_1h["close"]
        highs  = df_1h["high"]
        lows   = df_1h["low"]

        factors = {}

        # --- EMA trend ---
        ema20 = closes.ewm(span=20).mean()
        ema50 = closes.ewm(span=50).mean()
        factors["ema_trend"] = 1 if ema20.iloc[-1] > ema50.iloc[-1] else -1

        # --- RSI ---
        delta = closes.diff()
        gain  = delta.clip(lower=0).rolling(14).mean()
        loss  = (-delta.clip(upper=0)).rolling(14).mean()
        rs    = gain / (loss + 1e-9)
        rsi   = 100 - 100 / (1 + rs)
        rsi_val = rsi.iloc[-1]
        if rsi_val > 55:
            factors["rsi"] = 1
        elif rsi_val < 45:
            factors["rsi"] = -1
        else:
            factors["rsi"] = 0

        # --- ADX Trend Strength ---
        atr_vals = (highs - lows).rolling(14).mean()
        atr_avg  = atr_vals.iloc[-1]
        recent_rng = (highs.iloc[-20:].max() - lows.iloc[-20:].min())
        factors["volatility_context"] = "trending" if recent_rng > 3 * atr_avg else "ranging"

        # --- Price position vs 20-period range ---
        high20 = highs.iloc[-20:].max()
        low20  = lows.iloc[-20:].min()
        rng20  = high20 - low20
        pct_pos = (closes.iloc[-1] - low20) / (rng20 + 1e-9)
        if pct_pos > 0.65:
            factors["range_position"] = 1
        elif pct_pos < 0.35:
            factors["range_position"] = -1
        else:
            factors["range_position"] = 0

        # --- Higher Highs / Higher Lows (last 5 swing points) ---
        swing_hi = highs.rolling(3).max().iloc[-5::2]
        swing_lo = lows.rolling(3).min().iloc[-5::2]
        hh_hl = all(swing_hi.diff().dropna() > 0) and all(swing_lo.diff().dropna() > 0)
        lh_ll = all(swing_hi.diff().dropna() < 0) and all(swing_lo.diff().dropna() < 0)
        factors["structure"] = 1 if hh_hl else (-1 if lh_ll else 0)

        # --- Aggregate ---
        score_map = {k: v for k, v in factors.items() if isinstance(v, (int, float))}
        score = sum(score_map.values()) / (len(score_map) + 1e-9)

        if score > 0.3:
            bias = "bullish"
        elif score < -0.3:
            bias = "bearish"
        else:
            bias = "neutral"

        strength = min(abs(score), 1.0)

        return {
            "bias": bias,
            "strength": round(strength, 3),
            "rsi": round(rsi_val, 2),
            "ema_trend": "bullish" if factors["ema_trend"] == 1 else "bearish",
            "volatility": factors["volatility_context"],
            "factors": score_map
        }


# ============================================================
# DATA FETCHER (MT5)
# ============================================================

def fetch_mt5_data(symbol: str, timeframe, bars: int) -> Optional[pd.DataFrame]:
    if not MT5_AVAILABLE:
        log.error("MT5 not available.")
        return None
    if not mt5.initialize():
        log.error("MT5 initialize() failed: %s", mt5.last_error())
        return None
    rates = mt5.copy_rates_from_pos(symbol, timeframe, 0, bars)
    mt5.shutdown()
    if rates is None or len(rates) == 0:
        log.error("No data from MT5.")
        return None
    df = pd.DataFrame(rates)
    df["time"] = pd.to_datetime(df["time"], unit="s")
    df.rename(columns={"tick_volume": "volume"}, inplace=True)
    return df[["time", "open", "high", "low", "close", "volume"]]


def load_csv_data(path: str) -> pd.DataFrame:
    """Load OHLCV CSV. Expected columns: time,open,high,low,close,volume"""
    df = pd.read_csv(path, parse_dates=["time"])
    return df[["time", "open", "high", "low", "close", "volume"]]


# ============================================================
# FLASK API SERVER
# ============================================================

def create_server(model: CRTPatternClassifier, sentiment: SentimentEngine):
    if not FLASK_AVAILABLE:
        log.error("Flask not installed. Cannot start server.")
        return None

    app = Flask("CRT_ML_Server")

    @app.route("/health", methods=["GET"])
    def health():
        return jsonify({"status": "ok", "timestamp": datetime.utcnow().isoformat()})

    @app.route("/predict", methods=["POST"])
    def predict():
        """
        Expects JSON: { ...feature_dict... }
        Returns: { "signal": 0|1, "probability": float }
        """
        try:
            data = request.get_json(force=True)
            signal, prob = model.predict(data)
            return jsonify({"signal": signal, "probability": round(prob, 4)})
        except Exception as e:
            return jsonify({"error": str(e)}), 400

    @app.route("/sentiment", methods=["POST"])
    def sentiment_endpoint():
        """
        Expects JSON: { "bars": [ {open,high,low,close,volume}, ... ] }
        Returns daily bias info.
        """
        try:
            data    = request.get_json(force=True)
            bars    = data.get("bars", [])
            df_1h   = pd.DataFrame(bars)
            result  = sentiment.compute_bias(df_1h)
            return jsonify(result)
        except Exception as e:
            return jsonify({"error": str(e)}), 400

    @app.route("/train", methods=["POST"])
    def train_endpoint():
        """Trigger retraining from CSV path."""
        try:
            data = request.get_json(force=True)
            csv_path = data.get("csv_path", "")
            rr_ratio = float(data.get("rr_ratio", 2.0))
            df = load_csv_data(csv_path)
            result = model.train(df, rr_ratio)
            return jsonify(result)
        except Exception as e:
            return jsonify({"error": str(e)}), 400

    return app


# ============================================================
# BACKTEST RUNNER
# ============================================================

def run_backtest(df: pd.DataFrame, model: CRTPatternClassifier):
    log.info("Running backtest on %d bars...", len(df))
    features_df = FeatureEngineer.build_features(df)
    labels      = generate_labels(df, features_df, rr_ratio=2.0)

    combined = pd.concat([features_df, labels], axis=1).dropna()
    combined = combined[combined["sweep_direction"] != 0]
    combined = combined[combined["c2_closed_inside"] == 1]
    combined = combined[combined["c1_strong"] == 1]

    if len(combined) == 0:
        log.warning("No valid CRT setups found in backtest window.")
        return

    trades = []
    for _, row in combined.iterrows():
        feat = row.drop(["label", "bar_index"]).to_dict()
        try:
            signal, prob = model.predict(feat)
        except RuntimeError:
            signal, prob = 1, 0.5  # If no model trained, take all setups

        if signal == 1:
            trades.append({
                "bar_index": int(row["bar_index"]),
                "direction": "BUY" if row["sweep_direction"] == 1 else "SELL",
                "probability": round(prob, 4),
                "actual_win": int(row["label"])
            })

    if not trades:
        log.info("No trades qualified by ML filter.")
        return

    trades_df  = pd.DataFrame(trades)
    wins       = trades_df["actual_win"].sum()
    total      = len(trades_df)
    win_rate   = wins / total * 100

    log.info("=" * 50)
    log.info("BACKTEST RESULTS")
    log.info("Total trades taken (ML-filtered): %d", total)
    log.info("Wins: %d | Losses: %d", wins, total - wins)
    log.info("Win Rate: %.1f%%", win_rate)
    log.info("Net R: %.2f (assuming 1:2 RR, 1%% risk)", wins * 2 - (total - wins))
    log.info("=" * 50)
    log.info("\n%s", trades_df.head(20).to_string())


# ============================================================
# MAIN ENTRY
# ============================================================

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="CRT ML Model")
    parser.add_argument("--mode",    choices=["train", "backtest", "serve"], default="train")
    parser.add_argument("--symbol",  default="XAUUSD")
    parser.add_argument("--bars",    type=int, default=5000)
    parser.add_argument("--csv",     default="", help="Path to OHLCV CSV for training")
    parser.add_argument("--port",    type=int, default=5050)
    parser.add_argument("--model",   choices=["xgb", "rf", "gb", "lr"], default="xgb")
    parser.add_argument("--rr",      type=float, default=2.0)
    args = parser.parse_args()

    classifier = CRTPatternClassifier(model_type=args.model)
    sentiment  = SentimentEngine()

    if args.mode == "train":
        if args.csv:
            df = load_csv_data(args.csv)
        elif MT5_AVAILABLE:
            df = fetch_mt5_data(args.symbol, TF_H1, args.bars)
        else:
            log.error("Provide --csv path or install MetaTrader5 package.")
            sys.exit(1)
        if df is not None:
            classifier.train(df, rr_ratio=args.rr)

    elif args.mode == "backtest":
        try:
            classifier.load()
        except FileNotFoundError:
            log.warning("No saved model found. Training first...")
            if args.csv:
                df = load_csv_data(args.csv)
            elif MT5_AVAILABLE:
                df = fetch_mt5_data(args.symbol, TF_H1, args.bars)
            else:
                log.error("Provide --csv or MT5 package for data.")
                sys.exit(1)
            if df is not None:
                classifier.train(df, rr_ratio=args.rr)

        if args.csv:
            df = load_csv_data(args.csv)
        elif MT5_AVAILABLE:
            df = fetch_mt5_data(args.symbol, TF_H1, args.bars)
        else:
            log.error("Need data for backtest.")
            sys.exit(1)

        if df is not None:
            run_backtest(df, classifier)

    elif args.mode == "serve":
        try:
            classifier.load()
        except FileNotFoundError:
            log.warning("No model found. Server will accept /train requests to build one.")

        app = create_server(classifier, sentiment)
        if app:
            log.info("Starting CRT ML server on port %d...", args.port)
            app.run(host="0.0.0.0", port=args.port, debug=False)
        else:
            log.error("Could not create Flask server. Install Flask.")
